﻿namespace ZD8
{
    partial class FrmUnosAutomobila
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblProizvodjac = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.cmbProizvodjac = new System.Windows.Forms.ComboBox();
            this.lblModel = new System.Windows.Forms.Label();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.cmbGorivo = new System.Windows.Forms.ComboBox();
            this.lblGorivo = new System.Windows.Forms.Label();
            this.txtGodina = new System.Windows.Forms.TextBox();
            this.lblGodina = new System.Windows.Forms.Label();
            this.txtBrojVrata = new System.Windows.Forms.TextBox();
            this.lblBrojVrata = new System.Windows.Forms.Label();
            this.cmbBoja = new System.Windows.Forms.ComboBox();
            this.lblBoja = new System.Windows.Forms.Label();
            this.btnSpremi = new System.Windows.Forms.Button();
            this.btnOdustani = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(123, 23);
            this.txtId.Name = "txtId";
            this.txtId.ReadOnly = true;
            this.txtId.Size = new System.Drawing.Size(93, 20);
            this.txtId.TabIndex = 21;
            this.txtId.TabStop = false;
            // 
            // lblProizvodjac
            // 
            this.lblProizvodjac.AutoSize = true;
            this.lblProizvodjac.Location = new System.Drawing.Point(27, 52);
            this.lblProizvodjac.Name = "lblProizvodjac";
            this.lblProizvodjac.Size = new System.Drawing.Size(65, 13);
            this.lblProizvodjac.TabIndex = 20;
            this.lblProizvodjac.Text = "Proizvodjac:";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(27, 26);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(19, 13);
            this.lblId.TabIndex = 19;
            this.lblId.Text = "Id:";
            // 
            // cmbProizvodjac
            // 
            this.cmbProizvodjac.FormattingEnabled = true;
            this.cmbProizvodjac.Items.AddRange(new object[] {
            "Audi",
            "Citroen",
            "Ford",
            "Mercedes",
            "Peugeot",
            "Renault",
            "Toyota",
            "VW"});
            this.cmbProizvodjac.Location = new System.Drawing.Point(123, 49);
            this.cmbProizvodjac.Name = "cmbProizvodjac";
            this.cmbProizvodjac.Size = new System.Drawing.Size(245, 21);
            this.cmbProizvodjac.TabIndex = 23;
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Location = new System.Drawing.Point(27, 79);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(39, 13);
            this.lblModel.TabIndex = 24;
            this.lblModel.Text = "Model:";
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(123, 76);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(245, 20);
            this.txtModel.TabIndex = 25;
            // 
            // cmbGorivo
            // 
            this.cmbGorivo.FormattingEnabled = true;
            this.cmbGorivo.Items.AddRange(new object[] {
            "Diesel",
            "Benzin",
            "Plin"});
            this.cmbGorivo.Location = new System.Drawing.Point(123, 102);
            this.cmbGorivo.Name = "cmbGorivo";
            this.cmbGorivo.Size = new System.Drawing.Size(245, 21);
            this.cmbGorivo.TabIndex = 26;
            // 
            // lblGorivo
            // 
            this.lblGorivo.AutoSize = true;
            this.lblGorivo.Location = new System.Drawing.Point(27, 105);
            this.lblGorivo.Name = "lblGorivo";
            this.lblGorivo.Size = new System.Drawing.Size(41, 13);
            this.lblGorivo.TabIndex = 27;
            this.lblGorivo.Text = "Gorivo:";
            // 
            // txtGodina
            // 
            this.txtGodina.Location = new System.Drawing.Point(123, 129);
            this.txtGodina.Name = "txtGodina";
            this.txtGodina.Size = new System.Drawing.Size(245, 20);
            this.txtGodina.TabIndex = 28;
            // 
            // lblGodina
            // 
            this.lblGodina.AutoSize = true;
            this.lblGodina.Location = new System.Drawing.Point(27, 132);
            this.lblGodina.Name = "lblGodina";
            this.lblGodina.Size = new System.Drawing.Size(78, 13);
            this.lblGodina.TabIndex = 29;
            this.lblGodina.Text = "Godina proizv.:";
            // 
            // txtBrojVrata
            // 
            this.txtBrojVrata.Location = new System.Drawing.Point(123, 155);
            this.txtBrojVrata.Name = "txtBrojVrata";
            this.txtBrojVrata.Size = new System.Drawing.Size(245, 20);
            this.txtBrojVrata.TabIndex = 30;
            // 
            // lblBrojVrata
            // 
            this.lblBrojVrata.AutoSize = true;
            this.lblBrojVrata.Location = new System.Drawing.Point(27, 158);
            this.lblBrojVrata.Name = "lblBrojVrata";
            this.lblBrojVrata.Size = new System.Drawing.Size(55, 13);
            this.lblBrojVrata.TabIndex = 31;
            this.lblBrojVrata.Text = "Broj vrata:";
            // 
            // cmbBoja
            // 
            this.cmbBoja.FormattingEnabled = true;
            this.cmbBoja.Items.AddRange(new object[] {
            "Bijela",
            "Crvena",
            "Crna",
            "Plava",
            "Siva"});
            this.cmbBoja.Location = new System.Drawing.Point(123, 181);
            this.cmbBoja.Name = "cmbBoja";
            this.cmbBoja.Size = new System.Drawing.Size(245, 21);
            this.cmbBoja.TabIndex = 32;
            // 
            // lblBoja
            // 
            this.lblBoja.AutoSize = true;
            this.lblBoja.Location = new System.Drawing.Point(27, 184);
            this.lblBoja.Name = "lblBoja";
            this.lblBoja.Size = new System.Drawing.Size(31, 13);
            this.lblBoja.TabIndex = 33;
            this.lblBoja.Text = "Boja:";
            // 
            // btnSpremi
            // 
            this.btnSpremi.Location = new System.Drawing.Point(210, 208);
            this.btnSpremi.Name = "btnSpremi";
            this.btnSpremi.Size = new System.Drawing.Size(75, 28);
            this.btnSpremi.TabIndex = 35;
            this.btnSpremi.Text = "Spremi";
            this.btnSpremi.UseVisualStyleBackColor = true;
            // 
            // btnOdustani
            // 
            this.btnOdustani.Location = new System.Drawing.Point(291, 208);
            this.btnOdustani.Name = "btnOdustani";
            this.btnOdustani.Size = new System.Drawing.Size(75, 28);
            this.btnOdustani.TabIndex = 34;
            this.btnOdustani.Text = "Odustani";
            this.btnOdustani.UseVisualStyleBackColor = true;
            // 
            // FrmUnosAutomobila
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 267);
            this.Controls.Add(this.btnSpremi);
            this.Controls.Add(this.btnOdustani);
            this.Controls.Add(this.lblBoja);
            this.Controls.Add(this.cmbBoja);
            this.Controls.Add(this.lblBrojVrata);
            this.Controls.Add(this.txtBrojVrata);
            this.Controls.Add(this.lblGodina);
            this.Controls.Add(this.txtGodina);
            this.Controls.Add(this.lblGorivo);
            this.Controls.Add(this.cmbGorivo);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.lblModel);
            this.Controls.Add(this.cmbProizvodjac);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.lblProizvodjac);
            this.Controls.Add(this.lblId);
            this.Name = "FrmUnosAutomobila";
            this.Text = "Unos automobila";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblProizvodjac;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.ComboBox cmbProizvodjac;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.ComboBox cmbGorivo;
        private System.Windows.Forms.Label lblGorivo;
        private System.Windows.Forms.TextBox txtGodina;
        private System.Windows.Forms.Label lblGodina;
        private System.Windows.Forms.TextBox txtBrojVrata;
        private System.Windows.Forms.Label lblBrojVrata;
        private System.Windows.Forms.ComboBox cmbBoja;
        private System.Windows.Forms.Label lblBoja;
        private System.Windows.Forms.Button btnSpremi;
        private System.Windows.Forms.Button btnOdustani;
    }
}
﻿namespace ZD8
{
    partial class FrmPopisAutomobila
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvAutomobili = new System.Windows.Forms.DataGridView();
            this.lblAutomobili = new System.Windows.Forms.Label();
            this.btnIzmijeniAutomobil = new System.Windows.Forms.Button();
            this.btnObrisiAutomobil = new System.Windows.Forms.Button();
            this.btnDodajAutomobil = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAutomobili)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvAutomobili
            // 
            this.dgvAutomobili.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAutomobili.Location = new System.Drawing.Point(12, 30);
            this.dgvAutomobili.Name = "dgvAutomobili";
            this.dgvAutomobili.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAutomobili.Size = new System.Drawing.Size(731, 140);
            this.dgvAutomobili.TabIndex = 4;
            // 
            // lblAutomobili
            // 
            this.lblAutomobili.AutoSize = true;
            this.lblAutomobili.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblAutomobili.Location = new System.Drawing.Point(9, 14);
            this.lblAutomobili.Name = "lblAutomobili";
            this.lblAutomobili.Size = new System.Drawing.Size(107, 13);
            this.lblAutomobili.TabIndex = 3;
            this.lblAutomobili.Text = "Popis automobila:";
            // 
            // btnIzmijeniAutomobil
            // 
            this.btnIzmijeniAutomobil.Location = new System.Drawing.Point(574, 176);
            this.btnIzmijeniAutomobil.Name = "btnIzmijeniAutomobil";
            this.btnIzmijeniAutomobil.Size = new System.Drawing.Size(81, 34);
            this.btnIzmijeniAutomobil.TabIndex = 8;
            this.btnIzmijeniAutomobil.Text = "Izmijeni automobil";
            this.btnIzmijeniAutomobil.UseVisualStyleBackColor = true;
            // 
            // btnObrisiAutomobil
            // 
            this.btnObrisiAutomobil.Location = new System.Drawing.Point(487, 176);
            this.btnObrisiAutomobil.Name = "btnObrisiAutomobil";
            this.btnObrisiAutomobil.Size = new System.Drawing.Size(81, 34);
            this.btnObrisiAutomobil.TabIndex = 7;
            this.btnObrisiAutomobil.Text = "Obriši automobil";
            this.btnObrisiAutomobil.UseVisualStyleBackColor = true;
            // 
            // btnDodajAutomobil
            // 
            this.btnDodajAutomobil.Location = new System.Drawing.Point(661, 176);
            this.btnDodajAutomobil.Name = "btnDodajAutomobil";
            this.btnDodajAutomobil.Size = new System.Drawing.Size(81, 34);
            this.btnDodajAutomobil.TabIndex = 6;
            this.btnDodajAutomobil.Text = "Dodaj automobil";
            this.btnDodajAutomobil.UseVisualStyleBackColor = true;
            // 
            // FrmPopisAutomobila
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 231);
            this.Controls.Add(this.btnIzmijeniAutomobil);
            this.Controls.Add(this.btnObrisiAutomobil);
            this.Controls.Add(this.btnDodajAutomobil);
            this.Controls.Add(this.dgvAutomobili);
            this.Controls.Add(this.lblAutomobili);
            this.Name = "FrmPopisAutomobila";
            this.Text = "Popis automobila";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAutomobili)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAutomobili;
        private System.Windows.Forms.Label lblAutomobili;
        private System.Windows.Forms.Button btnIzmijeniAutomobil;
        private System.Windows.Forms.Button btnObrisiAutomobil;
        private System.Windows.Forms.Button btnDodajAutomobil;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Lab_2_4_EvidencijaStudenata
{
    public partial class GlavnaForma : Form
    {
        public GlavnaForma()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Osvježava DataGridView sa popisom timova.
        /// </summary>
        private void OsvjeziTimove()
        {
            List<Tim> listaTimova = Tim.DohvatiTimove();
            dgvTimovi.DataSource = listaTimova;
        }

        /// <summary>
        /// Rukuje događajem pokretanja glavne forme.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GlavnaForma_Load(object sender, EventArgs e)
        {
            OsvjeziTimove();
        }

        /// <summary>
        /// Rukuje događajem klika na gumb btnDodajTim. Otvara formu frmNoviTim
        /// u kojoj se upisuju podaci, a nakon zatvaranja forme osvježava prikaz timova.
        /// </summary>
        private void btnDodajTim_Click(object sender, EventArgs e)
        {
            NoviTim frmNoviTim = new NoviTim();
            frmNoviTim.ShowDialog();
            OsvjeziTimove();
        }

        /// <summary>
        /// Rukuje događajem klika na gumb btnIzmijeniTim. Dohvaća selektirani tim iz
        /// DataGridView kontrole, proslijeđuje ga formi frmNoviTim i ostvara formu.
        /// Nakon zatvaranja forme osvježava popis timova.
        /// </summary>
        private void btnIzmijeniTim_Click(object sender, EventArgs e)
        {
            if (dgvTimovi.SelectedRows.Count > 0)
            {
                Tim odabraniTim = dgvTimovi.SelectedRows[0].DataBoundItem as Tim;
                NoviTim frmNoviTim = new NoviTim(odabraniTim);
                frmNoviTim.ShowDialog();
                OsvjeziTimove();
            }
        }


        /// <summary>
        /// Rukuje događajem klika na gumb btnObrisiTim. Dohvaća selektirani tim/timove iz
        /// DataGridView kontrole, te ih briše.
        /// </summary>
        private void btnObrisiTim_Click(object sender, EventArgs e)
        {
            if (dgvTimovi.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvTimovi.SelectedRows)
                {
                    Tim odabraniTim = row.DataBoundItem as Tim;
                    odabraniTim.Obrisi();
                }
            }
            OsvjeziTimove();
        }
    }
}
